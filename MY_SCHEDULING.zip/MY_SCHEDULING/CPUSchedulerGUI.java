import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class CPUSchedulerGUI extends JFrame {

    private JComboBox<String> algoDropdown;
    private JTextField txtPt1, txtAt1, txtBt1;
    private JTextField txtPt2, txtAt2, txtBt2;
    private JTextField txtPt3, txtAt3, txtBt3;
    private JTextField txtPt4, txtAt4, txtBt4;
    private JButton btnRun;
    private GanttPanel ganttPanel;
    private JLabel lblAvgWT, lblAvgTAT, lblAvgRT, lblStatus;
    private DefaultTableModel tableModel;

    public CPUSchedulerGUI() {
        setTitle("CPU Scheduling Simulator - Complete GUI (P1-P4)");
        setSize(900, 680);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
        ((JPanel) getContentPane()).setBorder(new EmptyBorder(15, 15, 15, 15));
        getContentPane().setBackground(Color.WHITE);

        // ================= TOP SECTION (INPUTS) =================
        JPanel topPanel = new JPanel(new GridLayout(1, 2, 15, 0));
        topPanel.setBackground(Color.WHITE);

        // Left Card: Select Algorithm
        JPanel leftCard = new JPanel();
        leftCard.setLayout(new BoxLayout(leftCard, BoxLayout.Y_AXIS));
        leftCard.setBackground(Color.WHITE);
        leftCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(210, 215, 220), 1),
                new EmptyBorder(15, 15, 15, 15)
        ));

        JLabel lblSelect = new JLabel("Select Algorithm:");
        lblSelect.setFont(new Font("SansSerif", Font.BOLD, 14));
        lblSelect.setAlignmentX(Component.LEFT_ALIGNMENT);

        String[] algorithms = {
            "1. FCFS", 
            "2. SJF", 
            "3. SRTF", 
            "4. Priority", 
            "5. Round Robin"
        };
        algoDropdown = new JComboBox<>(algorithms);
        algoDropdown.setFont(new Font("SansSerif", Font.PLAIN, 14));
        algoDropdown.setMaximumSize(new Dimension(260, 35));
        algoDropdown.setAlignmentX(Component.LEFT_ALIGNMENT);

        leftCard.add(lblSelect);
        leftCard.add(Box.createRigidArea(new Dimension(0, 10)));
        leftCard.add(algoDropdown);

        // Right Card: Process Information (P1 to P4 with PT, AT, BT)
        JPanel rightCard = new JPanel(new GridBagLayout());
        rightCard.setBackground(Color.WHITE);
        rightCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(210, 215, 220), 1),
                new EmptyBorder(10, 15, 10, 15)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(2, 4, 2, 4);
        gbc.anchor = GridBagConstraints.WEST;

        JLabel lblProcInfo = new JLabel("Process Info (PT, AT, BT):");
        lblProcInfo.setFont(new Font("SansSerif", Font.BOLD, 14));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 6;
        rightCard.add(lblProcInfo, gbc);

        gbc.gridwidth = 1;

        // P1 Inputs
        gbc.gridx = 0; gbc.gridy = 1; rightCard.add(new JLabel("P1 PT:"), gbc);
        txtPt1 = new JTextField("0", 3); gbc.gridx = 1; rightCard.add(txtPt1, gbc);
        gbc.gridx = 2; rightCard.add(new JLabel("AT:"), gbc);
        txtAt1 = new JTextField("0", 3); gbc.gridx = 3; rightCard.add(txtAt1, gbc);
        gbc.gridx = 4; rightCard.add(new JLabel("BT:"), gbc);
        txtBt1 = new JTextField("7", 3); gbc.gridx = 5; rightCard.add(txtBt1, gbc);

        // P2 Inputs
        gbc.gridx = 0; gbc.gridy = 2; rightCard.add(new JLabel("P2 PT:"), gbc);
        txtPt2 = new JTextField("0", 3); gbc.gridx = 1; rightCard.add(txtPt2, gbc);
        gbc.gridx = 2; rightCard.add(new JLabel("AT:"), gbc);
        txtAt2 = new JTextField("1", 3); gbc.gridx = 3; rightCard.add(txtAt2, gbc);
        gbc.gridx = 4; rightCard.add(new JLabel("BT:"), gbc);
        txtBt2 = new JTextField("4", 3); gbc.gridx = 5; rightCard.add(txtBt2, gbc);

        // P3 Inputs
        gbc.gridx = 0; gbc.gridy = 3; rightCard.add(new JLabel("P3 PT:"), gbc);
        txtPt3 = new JTextField("0", 3); gbc.gridx = 1; rightCard.add(txtPt3, gbc);
        gbc.gridx = 2; rightCard.add(new JLabel("AT:"), gbc);
        txtAt3 = new JTextField("2", 3); gbc.gridx = 3; rightCard.add(txtAt3, gbc);
        gbc.gridx = 4; rightCard.add(new JLabel("BT:"), gbc);
        txtBt3 = new JTextField("3", 3); gbc.gridx = 5; rightCard.add(txtBt3, gbc);

        // P4 Inputs
        gbc.gridx = 0; gbc.gridy = 4; rightCard.add(new JLabel("P4 PT:"), gbc);
        txtPt4 = new JTextField("0", 3); gbc.gridx = 1; rightCard.add(txtPt4, gbc);
        gbc.gridx = 2; rightCard.add(new JLabel("AT:"), gbc);
        txtAt4 = new JTextField("3", 3); gbc.gridx = 3; rightCard.add(txtAt4, gbc);
        gbc.gridx = 4; rightCard.add(new JLabel("BT:"), gbc);
        txtBt4 = new JTextField("5", 3); gbc.gridx = 5; rightCard.add(txtBt4, gbc);

        // Run Button
        btnRun = new JButton("▶ Run Simulation");
        btnRun.setBackground(new Color(24, 100, 195));
        btnRun.setForeground(Color.WHITE);
        btnRun.setFocusPainted(false);
        btnRun.setFont(new Font("SansSerif", Font.BOLD, 12));
        btnRun.setCursor(new Cursor(Cursor.HAND_CURSOR));
        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 6;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        rightCard.add(btnRun, gbc);

        topPanel.add(leftCard);
        topPanel.add(rightCard);
        add(topPanel, BorderLayout.NORTH);

        // ================= CENTER SECTION (RESULTS) =================
        JPanel resultsContainer = new JPanel(new BorderLayout());
        resultsContainer.setBackground(Color.WHITE);
        resultsContainer.setBorder(BorderFactory.createLineBorder(new Color(210, 215, 220), 1));

        JPanel resultsHeader = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 8));
        resultsHeader.setBackground(new Color(25, 58, 105));
        JLabel lblResultsTitle = new JLabel("Results & Visualization");
        lblResultsTitle.setForeground(Color.WHITE);
        lblResultsTitle.setFont(new Font("SansSerif", Font.BOLD, 15));
        resultsHeader.add(lblResultsTitle);
        resultsContainer.add(resultsHeader, BorderLayout.NORTH);

        JPanel resultsBody = new JPanel(new GridLayout(1, 2, 15, 0));
        resultsBody.setBackground(Color.WHITE);
        resultsBody.setBorder(new EmptyBorder(15, 15, 15, 15));

        JPanel leftResults = new JPanel();
        leftResults.setLayout(new BoxLayout(leftResults, BoxLayout.Y_AXIS));
        leftResults.setBackground(Color.WHITE);

        JLabel lblGantt = new JLabel("Gantt Chart:");
        lblGantt.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblGantt.setAlignmentX(Component.LEFT_ALIGNMENT);

        ganttPanel = new GanttPanel();
        ganttPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        lblAvgWT = new JLabel("Average Waiting Time:       0.00");
        lblAvgWT.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblAvgWT.setAlignmentX(Component.LEFT_ALIGNMENT);

        lblAvgTAT = new JLabel("Average Turnaround Time: 0.00");
        lblAvgTAT.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblAvgTAT.setAlignmentX(Component.LEFT_ALIGNMENT);

        lblAvgRT = new JLabel("Average Response Time:    0.00");
        lblAvgRT.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblAvgRT.setAlignmentX(Component.LEFT_ALIGNMENT);

        leftResults.add(lblGantt);
        leftResults.add(Box.createRigidArea(new Dimension(0, 8)));
        leftResults.add(ganttPanel);
        leftResults.add(Box.createRigidArea(new Dimension(0, 15)));
        leftResults.add(lblAvgWT);
        leftResults.add(Box.createRigidArea(new Dimension(0, 4)));
        leftResults.add(lblAvgTAT);
        leftResults.add(Box.createRigidArea(new Dimension(0, 4)));
        leftResults.add(lblAvgRT);

        JPanel rightResults = new JPanel(new BorderLayout(0, 8));
        rightResults.setBackground(Color.WHITE);

        JLabel lblDetails = new JLabel("Details Table:");
        lblDetails.setFont(new Font("SansSerif", Font.BOLD, 13));
        rightResults.add(lblDetails, BorderLayout.NORTH);

        String[] columns = {"Process", "PT", "AT", "BT", "CT", "TAT", "WT", "RT"};
        tableModel = new DefaultTableModel(columns, 0);
        JTable table = new JTable(tableModel);
        table.setRowHeight(20);
        table.getTableHeader().setBackground(new Color(240, 243, 247));
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 11));

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < columns.length; i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(380, 130));
        rightResults.add(scrollPane, BorderLayout.CENTER);

        resultsBody.add(leftResults);
        resultsBody.add(rightResults);
        resultsContainer.add(resultsBody, BorderLayout.CENTER);
        add(resultsContainer, BorderLayout.CENTER);

        // ================= BOTTOM STATUS BADGE =================
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.setBackground(Color.WHITE);
        lblStatus = new JLabel(" ✔  Simulation Completed Successfully! ");
        lblStatus.setOpaque(true);
        lblStatus.setBackground(new Color(218, 245, 222));
        lblStatus.setForeground(new Color(25, 105, 45));
        lblStatus.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblStatus.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(140, 210, 150), 1),
                new EmptyBorder(6, 18, 6, 18)
        ));
        lblStatus.setVisible(false);
        bottomPanel.add(lblStatus);
        add(bottomPanel, BorderLayout.SOUTH);

        btnRun.addActionListener(e -> runSimulation());
        runSimulation();
    }

    private void runSimulation() {
        try {
            int pt1 = Integer.parseInt(txtPt1.getText().trim());
            int at1 = Integer.parseInt(txtAt1.getText().trim());
            int bt1 = Integer.parseInt(txtBt1.getText().trim());

            int pt2 = Integer.parseInt(txtPt2.getText().trim());
            int at2 = Integer.parseInt(txtAt2.getText().trim());
            int bt2 = Integer.parseInt(txtBt2.getText().trim());

            int pt3 = Integer.parseInt(txtPt3.getText().trim());
            int at3 = Integer.parseInt(txtAt3.getText().trim());
            int bt3 = Integer.parseInt(txtBt3.getText().trim());

            int pt4 = Integer.parseInt(txtPt4.getText().trim());
            int at4 = Integer.parseInt(txtAt4.getText().trim());
            int bt4 = Integer.parseInt(txtBt4.getText().trim());

            ArrayList<CPUSchedulerSimulator.Process> plist = new ArrayList<>();
            plist.add(new CPUSchedulerSimulator.Process("1", at1, bt1, pt1));
            plist.add(new CPUSchedulerSimulator.Process("2", at2, bt2, pt2));
            plist.add(new CPUSchedulerSimulator.Process("3", at3, bt3, pt3));
            plist.add(new CPUSchedulerSimulator.Process("4", at4, bt4, pt4));

            String selected = (String) algoDropdown.getSelectedItem();
            
            if (selected != null) {
                if (selected.contains("FCFS")) {
                    CPUSchedulerSimulator.runFCFS(plist);
                } else if (selected.contains("SJF")) {
                    CPUSchedulerSimulator.runSJFNonPreemptive(plist);
                } else if (selected.contains("SRTF")) {
                    CPUSchedulerSimulator.runSRTF(plist);
                } else if (selected.contains("Priority")) {
                    CPUSchedulerSimulator.runPriority(plist);
                } else if (selected.contains("Round Robin")) {
                    CPUSchedulerSimulator.runRoundRobin(plist, 3);
                }
            }

            List<GanttPanel.Block> blocks = new ArrayList<>();
            plist.sort((a, b) -> Integer.compare(a.at, b.at));

            int currentT = 0;
            Color[] colors = {
                new Color(179, 212, 252), 
                new Color(185, 235, 185), 
                new Color(252, 205, 155),
                new Color(245, 180, 200)
            };
            
            for (int i = 0; i < plist.size(); i++) {
                CPUSchedulerSimulator.Process p = plist.get(i);
                if (currentT < p.at) {
                    blocks.add(new GanttPanel.Block("IDLE", currentT, p.at, new Color(230, 230, 230)));
                    currentT = p.at;
                }
                int start = currentT;
                int end = start + p.bt;
                blocks.add(new GanttPanel.Block("P" + p.pid, start, end, colors[i % colors.length]));
                currentT = end;
            }

            ganttPanel.setBlocks(blocks);

            tableModel.setRowCount(0);
            double totalWt = 0, totalTat = 0, totalRt = 0;
            for (CPUSchedulerSimulator.Process p : plist) {
                tableModel.addRow(new Object[]{"P" + p.pid, p.priority, p.at, p.bt, p.ct, p.tat, p.wt, p.rt});
                totalWt += p.wt;
                totalTat += p.tat;
                totalRt += p.rt;
            }

            lblAvgWT.setText(String.format("Average Waiting Time:       %.2f", totalWt / plist.size()));
            lblAvgTAT.setText(String.format("Average Turnaround Time: %.2f", totalTat / plist.size()));
            lblAvgRT.setText(String.format("Average Response Time:    %.2f", totalRt / plist.size()));
            lblStatus.setVisible(true);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Mangyaring maglagay ng wastong numero sa lahat ng PT, AT, at BT fields.");
        }
    }

    static class GanttPanel extends JPanel {
        static class Block {
            String pid;
            int start, end;
            Color color;
            Block(String pid, int start, int end, Color color) {
                this.pid = pid; this.start = start; this.end = end; this.color = color;
            }
        }

        private List<Block> blocks = new ArrayList<>();

        public GanttPanel() {
            setPreferredSize(new Dimension(380, 70));
            setMaximumSize(new Dimension(400, 70));
            setBackground(Color.WHITE);
        }

        public void setBlocks(List<Block> blocks) {
            this.blocks = blocks;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (blocks.isEmpty()) return;

            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int totalTime = blocks.get(blocks.size() - 1).end;
            if (totalTime == 0) totalTime = 1;
            int barWidth = getWidth() - 35;
            int barHeight = 35;
            int startX = 15;
            int startY = 8;

            g2.setFont(new Font("SansSerif", Font.BOLD, 11));
            g2.drawString("0", startX - 3, startY + barHeight + 18);

            for (Block b : blocks) {
                int x1 = startX + (int) ((double) b.start / totalTime * barWidth);
                int x2 = startX + (int) ((double) b.end / totalTime * barWidth);
                int w = Math.max(x2 - x1, 26);

                g2.setColor(b.color);
                g2.fillRect(x1, startY, w, barHeight);

                g2.setColor(Color.DARK_GRAY);
                g2.drawRect(x1, startY, w, barHeight);

                FontMetrics fm = g2.getFontMetrics();
                String label = b.pid;
                int labelX = x1 + (w - fm.stringWidth(label)) / 2;
                int labelY = startY + (barHeight + fm.getAscent()) / 2 - 2;
                g2.drawString(label, labelX, labelY);

                String timeStr = String.valueOf(b.end);
                g2.drawString(timeStr, x2 - fm.stringWidth(timeStr) / 2, startY + barHeight + 18);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CPUSchedulerGUI().setVisible(true));
    }
}